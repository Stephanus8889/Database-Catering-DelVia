create database CateringdelVia

use CateringdelVia

drop database CateringdelVia
create table Menu(
	Menu_ID char(5) primary key check(Menu_ID LIKE 'ME[0-9][0-9][0-9]'),
	[Name] varchar (50) check(len([Name])>5) NOT NULL,
	[Description] varchar(100),
	Price int NOT NULL
)

create table menu_services_transaction_detail(
	Menumenu_ID char(5) foreign key references Menu(Menu_ID) on update cascade on delete cascade,
	services_transactiontransactionID char(5) foreign key references service_transaction(transactionID) on update cascade on delete cascade,
	primary key (Menumenu_ID, services_transactiontransactionID)
)

create table customer(
	CustomerID char(5) primary key check(CustomerID LIKE 'CU[0-9][0-9][0-9]'),
	[Name] varchar (50) NOT NULL,
	Phonenumber varchar (13) check(phonenumber LIKE '08[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]%') NOT NULL,
	[Address] varchar (100) NOT NULL,
	Gender varchar (10) NOT NULL,
	Email varchar (50)  check(email NOT LIKE '@%' AND (email LIKE '%@gmail.com' OR email LIKE '%@yahoo.com' OR email LIKE'%@yahoo.co.id')) NOT NULL
)

create table Staff(
	StaffID char(5) Primary key check(StaffID LIKE 'ST[0-9][0-9][0-9]'),
	StaffPositionID char(5) foreign key references position(StaffPositionID),
	[Name] varchar (50) NOT NULL,
	Gender varchar (10) NOT NULL,
	Email varchar (50) check(Email NOT LIKE '@%' AND (Email LIKE '%@gmail.com' OR Email LIKE '%@yahoo.com' OR Email LIKE'%@yahoo.co.id'))NOT NULL,
	PhoneNumber varchar(13) check(PhoneNumber LIKE '08[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]%') NOT NULL,
	[Address] varchar (100) NOT NULL,  
	Salary numeric(11,2) check(Salary between 500000 AND 5000000) NOT NULL
)

create table service_transaction (
	[transactionID] char(5) primary key check([transactionID] LIKE 'TR[0-9][0-9][0-9]'),
	StaffID char(5) foreign key references Staff(StaffID),
	CustomerID char (5) foreign key references customer(CustomerID) ,
	Transaction_date date NOT NULL,
	Reservation_type varchar(50) NOT NULL,
	Reservation_address varchar (100) NOT NULL ,
	Pax_menu integer NOT NULL
)
create table position(
	StaffPositionID char (5) Primary Key Check(StaffPositionID LIKE 'SP[0-9][0-9][0-9]'),
	Position_name varchar (20) NOT NULL
)

create table ingredient(
	ingredient_ID char(5) primary key Check(ingredient_ID LIKE 'ID[0-9][0-9][0-9]'),
	[Name] varchar(50) NOT NULL,
	Stock int NOT NULL,
	Price numeric(11,2) NOT NULL
)

create table ingredient_purchase_detail(
	ingredient_ingredient_ID char(5) foreign key references ingredient(ingredient_ID) on update cascade on delete cascade,
	purchase_purchase_ID char(5) foreign key references purchase(purchase_ID) on update cascade on delete cascade,
	quantity_ingredient int NOT NULL
	primary key(ingredient_ingredient_ID, purchase_purchase_ID)
)

create table purchase(
	purchase_ID char(5) primary key Check(purchase_ID LIKE 'PU[0-9][0-9][0-9]'),
	StaffID char(5),
	VendorID char(5),
	Purchase_date date NOT NULL, 
	foreign key(StaffID) references Staff(StaffID),
	foreign key(VendorID) references vendor(VendorID)
)

create table vendor(
	VendorID char(5) primary key Check(VendorID LIKE 'VE[0-9][0-9][0-9]'),
	[Name] varchar(50) check([name] LIKE 'PT.%') NOT NULL, 
	Phonenumber varchar(13) NOT NULL, 
	[Address] varchar(100) NOT NULL
)

insert into customer values('CU001', 'Stephanus', '081219438365', 'Jl. Taman Apel','Male','Stephanus@gmail.com')
insert into customer values('CU002', 'Andrew', '081689302212', 'Jl. Tanjung Duren','Male','Andrew@gmail.com')
insert into customer values('CU003', 'Luna','081420301232', 'Permata Buana','Female','Luna@yahoo.co.id')
insert into customer values('CU004', 'Prilly','081309823421', 'Green Lake','Female','Prilly@yahoo.co.id')
insert into customer values('CU005', 'Andy', '081012345689', 'Jl. Ahmad Yani','Male','Andy@yahoo.com')
insert into customer values('CU006','Budi','083213127568','Jl.Patimmura','Male','Budiono@gmail.com')
insert into customer values('CU007','Asep','083223199560','Jl. Kebangsaan','Male','Asep8@gmail.com')
insert into customer values('CU008','Aurel','083244127575','Jl. Cianjur','Female','Aurel5@yahoo.co.id')
insert into customer values('CU009','Putri','083256124500','Jl. Mangga','Female','Putri23@yahoo.com')
insert into customer values('CU010','Brody','083243127488','Jl. Terbaik','Male','Brody00@gmail.com')
select* from customer

insert into vendor values('VE001', 'PT.Sandy', '081909212342', 'Jl. Taman Ratu')
insert into vendor values('VE002', 'PT.Raffi', '081309231023', 'Pasar Baru')
insert into vendor values('VE003', 'PT.Lala', '081323442232', 'Jl. Sulaiman')
insert into vendor values('VE004','PT.Sumiha','089356421378','Jl. Semangka')
insert into vendor values('VE005','PT.Dalmi','089352421998','Jl. Benedita')
insert into vendor values('VE006','PT.Jipyeong','089355677378','Jl. Vivio')
insert into vendor values ('VE007','PT.Baim','0812685193789','Jl.Macan')
insert into vendor values ('VE008','PT.Anggi','0812685231789','Jl.Maret')
insert into vendor values ('VE009','PT.Anggun','0812123193789','Jl.Sudirman')
insert into vendor values ('VE010','PT.Clarita','0812685194569','Jl.Setiabudi')
select* from vendor

insert into ingredient values('ID001', 'Ayam', 120, 45000)
insert into ingredient values('ID002', 'Telur', 500, 65000)
insert into ingredient values('ID003', 'Tahu', 300, 10000)
insert into ingredient values('ID004','Ikan Gurame',100,90000)
insert into ingredient values('ID005','beras',1500,250000)
insert into ingredient values('ID006','ikan Kakap',130,120000)
insert into ingredient values('ID007','Babi',80,70000)
insert into ingredient values('ID008','Bakso',120,10000)
insert into ingredient values('ID009','Bebek',120,45000)
insert into ingredient values('ID010','Kambing',80,80000)
select* from ingredient

insert into Menu values('ME001', 'Tahu Telur Surabaya', 'Setengah Porsi atau Satu Porsi', 35000)
insert into Menu values('ME002', 'Gurame Asam Manis', 'Porsi Kecil (3 ons) atau Porsi Besar(6 ons)', 20000)
insert into Menu values('ME003', 'Kambing Gulai', 'Porsi Kecil atau Porsi Besar', 45000)
insert into Menu values('ME004', 'Sate Babi', 'Per Tusuk ', 8000)
insert into Menu values('ME005', 'Bakso Goreng', 'Per Satuan ', 9000)
insert into Menu values('ME006', 'Nasi Goreng Hongkong', 'Porsi Kecil atau Porsi Besar', 32000)
insert into Menu values('ME007', 'Babi Panggang', 'Porsi Kecil (3 ons) atau Porsi Besar (6 ons)', 50000)
insert into Menu values('ME008', 'Tim Kakap Merah', 'Porsi Kecil (3 ons) atau Porsi Besar (6 ons)', 65000)
insert into Menu values('ME009', 'Ayam Taliwang', 'Setengah Porsi atau Satu Porsi', 50000)
insert into Menu values('ME010', 'Bebek Peking', 'Setengah Porsi atau Satu Porsi', 65000)
select* from Menu

insert into position values('SP001', 'Secretary')
insert into position values('SP002', 'Inventory Manager')
insert into position values('SP003', 'Head Chef')
insert into position values('SP004','Promotion')
insert into position values('SP005','Cashier')
insert into position values('SP006','Supervisor')
insert into position values('SP007','CEO')
insert into position values('SP008','Chef')
insert into position values('SP009','Treasurer')
insert into position values('SP010','Marketing')
select* from position

insert into Staff values('ST001','SP002','Christian Robbert', 'Male', 'Christian123@gmail.com', '081823489212', 'Jl. Jatinegara', 3200000)
insert into Staff values('ST002','SP004','Albert ', 'Male', 'Albert0988@yahoo.com', '081980923422', 'Jl. Kelapa Gading', 4100000)
insert into Staff values('ST003','SP006','Gabriella Angelica', 'Female', 'Gaby@yahoo.co.id', '081345609852', 'Jl. Surya Kencana', 3200000)
insert into Staff values('ST004','SP001','Taisho ','Male','Taisho@gmail.com','089323451678','Jl. Manggis',2500000)
insert into Staff values('ST005','SP007','Priska ','Female','Priska87@gmail.com','089366451078','Jl. Cookies',3500000)
insert into Staff values('ST006','SP009','Silvy Putri','Female','Silvy78@yahoo.com','089326851247','Jl. Mantaps',2000000)
insert into Staff values('ST007','SP010','Kevin Sanjaya','Male','kevin1@gmail.com','0812654987123','Jl.Menceng',1000000)
insert into Staff values('ST008','SP003','Doryan ','Male','Doryan@gmail.com','0812654555123','Jl.Pamulang',5000000)
insert into Staff values('ST009','SP005','Govindo ','Male','Govindo@gmail.com','0812657897123','Jl.Taman Palem',2000000)
insert into Staff values('ST010','SP008','Jecelline Natasya','Female','Jecee@gmail.com','0812654987987','Jl.Taman Kencana',3000000)
select* from Staff

insert into service_transaction values('TR001', 'ST008', 'CU002', '2020-10-20', 'Birthday Party', 'Jl. Daan Mogot', 100)
insert into service_transaction values('TR002', 'ST009', 'CU005', '2020-08-11', 'Weddings', 'Jl. Hayam Wuruk', 200)
insert into service_transaction values('TR003', 'ST001', 'CU006', '2020-05-13', 'Thanks Giving Event', 'Jl. Dewi Sartika', 70)
insert into service_transaction values('TR004', 'ST010', 'CU004', '2020-08-05', 'Catering', 'Jl. Thamrin', 50)
insert into service_transaction values('TR005', 'ST002', 'CU001', '2020-01-04', 'Farewell Party', 'Jl. Ahmad', 200)
insert into service_transaction values('TR006', 'ST005', 'CU010', '2020-11-12', 'Weddings', 'Jl. Rasuna Said', 300)
insert into service_transaction values('TR007', 'ST007', 'CU003', '2020-01-01', 'Happy New Year', 'Jl. Subroto', 50)
insert into service_transaction values('TR008', 'ST003', 'CU007', '2020-12-12', 'Farewell Party', 'Jl. Sudarso', 200)
insert into service_transaction values('TR009', 'ST004', 'CU008', '2020-10-10', 'Birthday Party', 'Green Ville', 70)
insert into service_transaction values('TR010', 'ST006', 'CU009', '2020-04-17', 'Thanks Giving Event', 'Jl. Delima', 40)
insert into service_transaction values('TR011', 'ST003', 'CU007', '2020-12-28','Catering', 'Jl. Mayora', 100)
insert into service_transaction values('TR012', 'ST005', 'CU009', '2020-11-23', 'Birthday Party', 'Jl. Medan', 45)
insert into service_transaction values('TR013', 'ST002', 'CU004', '2020-03-26', 'Farewell Party', 'Jl. Jatinegara', 200)
insert into service_transaction values('TR014', 'ST003', 'CU001', '2020-07-25', 'Weddings', 'Hotel Ritz', 500)
insert into service_transaction values('TR015', 'ST007', 'CU010', '2020-01-21', 'Birthday Party', 'Hotel MUlia', 550)
select* from service_transaction

insert into purchase values('PU001','ST003','VE002','2020-08-03')
insert into purchase values('PU002','ST004','VE005','2020-11-28')
insert into purchase values('PU003','ST008','VE002','2020-02-04')
insert into purchase values('PU004','ST001','VE003','2020-04-08')
insert into purchase values('PU005','ST006','VE008','2020-01-03')
insert into purchase values('PU006','ST002','VE008','2020-08-05')
insert into purchase values('PU007','ST010','VE009','2020-06-10')
insert into purchase values('PU008','ST007','VE006','2020-12-21')
insert into purchase values('PU009','ST005','VE007','2020-07-18')
insert into purchase values('PU010','ST009','VE001','2020-02-13')
insert into purchase values('PU011','ST006','VE007','2020-12-08')
insert into purchase values('PU012','ST010','VE010','2020-10-10')
insert into purchase values('PU013','ST009','VE001','2020-02-20')
insert into purchase values('PU014','ST003','VE005','2020-05-01')
insert into purchase values('PU015','ST007','VE002','2020-12-12')
select* from purchase

insert into menu_services_transaction_detail values('ME003','TR012')    
insert into menu_services_transaction_detail values('ME002','TR005')       
insert into menu_services_transaction_detail values('ME007','TR011')
insert into menu_services_transaction_detail values('ME005','TR009')
insert into menu_services_transaction_detail values('ME002','TR001')
insert into menu_services_transaction_detail values('ME002','TR008')
insert into menu_services_transaction_detail values('ME009','TR010')
insert into menu_services_transaction_detail values('ME009','TR015')
insert into menu_services_transaction_detail values('ME004','TR007')
insert into menu_services_transaction_detail values('ME001','TR010')
insert into menu_services_transaction_detail values('ME010','TR013')
insert into menu_services_transaction_detail values('ME008','TR001')
insert into menu_services_transaction_detail values('ME006','TR005')
insert into menu_services_transaction_detail values('ME005','TR011')
insert into menu_services_transaction_detail values('ME007','TR002')
insert into menu_services_transaction_detail values('ME003','TR006')
insert into menu_services_transaction_detail values('ME001','TR003')
insert into menu_services_transaction_detail values('ME005','TR005')
insert into menu_services_transaction_detail values('ME002','TR010')
insert into menu_services_transaction_detail values('ME010','TR004')
insert into menu_services_transaction_detail values('ME001','TR014')
insert into menu_services_transaction_detail values('ME008','TR011')
insert into menu_services_transaction_detail values('ME010','TR001')
insert into menu_services_transaction_detail values('ME004','TR010')
insert into menu_services_transaction_detail values('ME002','TR012')
select* from menu_services_transaction_detail

insert into ingredient_purchase_detail values('ID003','PU004',3)
insert into ingredient_purchase_detail values('ID005','PU006',4)
insert into ingredient_purchase_detail values('ID008','PU007',7)
insert into ingredient_purchase_detail values('ID002','PU008',2)
insert into ingredient_purchase_detail values('ID001','PU012',5)
insert into ingredient_purchase_detail values('ID010','PU011',3)
insert into ingredient_purchase_detail values('ID009','PU003',6)
insert into ingredient_purchase_detail values('ID005','PU010',9)
insert into ingredient_purchase_detail values('ID007','PU002',5)
insert into ingredient_purchase_detail values('ID004','PU015',6)
insert into ingredient_purchase_detail values('ID008','PU002',5)
insert into ingredient_purchase_detail values('ID005','PU009',7)
insert into ingredient_purchase_detail values('ID001','PU004',4)
insert into ingredient_purchase_detail values('ID006','PU005',8)
insert into ingredient_purchase_detail values('ID002','PU001',3)
insert into ingredient_purchase_detail values('ID010','PU008',5)
insert into ingredient_purchase_detail values('ID007','PU003',4)
insert into ingredient_purchase_detail values('ID001','PU002',12)
insert into ingredient_purchase_detail values('ID005','PU013',8)
insert into ingredient_purchase_detail values('ID006','PU010',13)
insert into ingredient_purchase_detail values('ID003','PU013',2)
insert into ingredient_purchase_detail values('ID004','PU014',10)
insert into ingredient_purchase_detail values('ID009','PU007',12)
insert into ingredient_purchase_detail values('ID008','PU010',9)
insert into ingredient_purchase_detail values('ID002','PU011',2)
select* from ingredient_purchase_detail

--1
select st.[Name] as [StaffName], pt.Position_name as[StaffPositionName], count(st.StaffID)as [Total Activity]
from Staff st join position pt on st.StaffPositionID = pt.StaffPositionID join service_transaction stn on st.StaffID = stn.StaffID join purchase pc on st.StaffID = pc.StaffID 
where st.Salary between 1000000 AND 4000000
group by st.[Name], pt.Position_name HAVING count(stn.StaffID)>2

--2
select c.CustomerID, c.[Name] as [Customer Name], sum(st.Pax_menu) as [Pax Bought]
from customer c join service_transaction st on c.CustomerID = st.CustomerID
where c.Gender = 'Male' AND Month(st.Transaction_date) between 01 and 06 
group by c.CustomerID, c.[Name]

select*from customer
select*from service_transaction

--3
select ing.[Name], sum(ipd.quantity_ingredient) as [Ingredient Bought], count(p.purchase_ID) as [Purchase Count], sum(ipd.quantity_ingredient* ing.Price) as [Total Expenses]
from ingredient_purchase_detail ipd join ingredient ing on ing.ingredient_ID = ipd.ingredient_ingredient_ID join purchase p on p.purchase_ID = ipd.purchase_purchase_ID
where MONTH(p.Purchase_date)%2=0 and DAY(p.Purchase_date) between 02 and 05 
group by (ing.[Name])

select * from ingredient
select * from ingredient_purchase_detail
select * from purchase

--4
select left(st.[Name], CHARINDEX(' ', st.[Name])) as [StaffFirstName], COUNT(stn.transactionID) as [Transaction Count], SUM(stn.Pax_menu) as [Pax Sold] 
from service_transaction stn join Staff st on stn.StaffID = st.StaffID join customer ct on stn.CustomerID = ct.CustomerID
where RIGHT(st.StaffID, 1) %2 = 1 AND RIGHT(ct.CustomerID, 1) %2 = 0
group by st.[Name]

--5
--select SUBSTRING(v.[Name], 4, LEN(V.[Name])) as [Vendor Name], i.[Name], 'Rp.' + cast(i.[Price] as varchar) as[Ingredient Price]
--from ingredient_purchase_detail ipd join ingredient i on ipd.ingredient_ingredient_ID = i.ingredient_ID join purchase p on ipd.purchase_purchase_ID = p.purchase_ID join vendor v on p.VendorID = v.VendorID   
--where i.Price > (Select AVG(i.Price) from ingredient i where i.Stock < 250)

--select SUBSTRING(v.[Name], 4, LEN(V.[Name])) as [Vendor Name], i.[Name], 'Rp.' + cast(i.[Price] as varchar) as[Ingredient Price]
--from ingredient_purchase_detail ipd join ingredient i on ipd.ingredient_ingredient_ID = i.ingredient_ID join purchase p on ipd.purchase_purchase_ID = p.purchase_ID join vendor v on p.VendorID = v.VendorID   
--where i.Price >= (Select AVG(i.Price) from ingredient i) and i.Stock < 250

select SUBSTRING(v.[Name], 4, LEN(V.[Name])) as [Vendor Name], i.[Name], 'Rp.' + cast(i.[Price] as varchar) as[Ingredient Price]
from ingredient_purchase_detail ipd join ingredient i on ipd.ingredient_ingredient_ID = i.ingredient_ID join purchase p on ipd.purchase_purchase_ID = p.purchase_ID join vendor v on p.VendorID = v.VendorID, (Select value = AVG(i.Price) from ingredient i) as A
where i.Price >= A.value and i.Stock < 250

--6
select c.[Name]  as [Customer Name], CONVERT(varchar, st.Transaction_date, 107) as [TransactionDate], m.[Name] as [Menu Name], SUBSTRING(m.[Description],1, CHARINDEX(' ', m.[Description], CHARINDEX(' ', m.[Description], 1)+1)) as [Biref Description] ,st.Pax_menu , m.Price * st.Pax_menu as [Total Price]
from  menu_services_transaction_detail mst join Menu m on mst.Menumenu_ID = m.Menu_ID join service_transaction st on mst.services_transactiontransactionID = st.transactionID join customer c on c.CustomerID = st.CustomerID, (Select AveragePrice = AVG(m.Price) from Menu m) as AP
where m.Price > AP.AveragePrice and st.Pax_menu > 100
--group by c.[Name], st.Transaction_date, m.[Name], m.[Description], st.Pax_menu


--7
select UPPER(s.[Name]) as [Staff Name], CONVERT(varchar, p.Purchase_date, 107) as [Purchase Date], cast(SUM(quantity_ingredient)as varchar) + ' pcs' as [Quantity Bought]
from ingredient_purchase_detail ipd join ingredient i on ipd.ingredient_ingredient_ID = i.ingredient_ID join purchase p on ipd.purchase_purchase_ID = p.purchase_ID join Staff s on p.StaffID = s.StaffID, (Select maxvalue = MAX(i.Price) from ingredient i) as A
where MONTH(p.Purchase_date)%2 = 0 and (i.[Price] < A.maxvalue)
Group by s.[Name], p.Purchase_date 

--8
select c.[Name] as [Customer Name], SUBSTRING(c.Email, 0, CHARINDEX('@', c.Email, 0)) as [Email], LOWER(m.[Name]) as [Menu Name], SUM(st.Pax_menu) as [Pax Bought]
from menu_services_transaction_detail mst join menu m on m.Menu_ID = mst.Menumenu_ID join service_transaction st on mst.services_transactiontransactionID = st.transactionID join customer c on c.CustomerID = st.CustomerID, (Select average = AVG(st.Pax_menu) from service_transaction st) as Harga_Rata_Rata
where c.Gender = 'Male' and st.Pax_menu >= Harga_Rata_Rata.average
GROUP BY c.[Name], c.Email, m.[Name]

--9
create view [LoyalCustomerView] AS
select c.[Name] as [CustomerName], Count(c.CustomerID) as [Total Transaction], SUM(st.Pax_menu) as [Total Pax Purchased], SUM(st.Pax_menu * m.Price) as [Total price]
from menu_services_transaction_detail mst join Menu m on mst.Menumenu_ID = m.Menu_ID join service_transaction st on mst.services_transactiontransactionID = st.transactionID join customer c on st.CustomerID = c.CustomerID 
where c.Gender = 'female' 
GROUP BY c.[Name] having count(c.CustomerID) > 2

select* from [LoyalCustomerView]

--10
create view [VendorRecapView] AS
select v.[Name] as [VendorName], COUNT(v.VendorID) as [Purchases Made], SUM(ipd.quantity_ingredient) as [Ingredients Purchased]
from ingredient_purchase_detail ipd join ingredient i on ipd.ingredient_ingredient_ID = i.ingredient_ID join purchase p on ipd.purchase_purchase_ID = p.purchase_ID join vendor v on p.VendorID = v.VendorID
where i.Stock > 150
group by v.[Name] having COUNT(v.VendorID) > 1

select* from [VendorRecapView]

select*from Menu
select* from menu_services_transaction_detail
select*from service_transaction
select* from customer
--select*from ingredient
--select* from ingredient_purchase_detail
--select* from purchase
select* from vendor

select*from Staff
select*from position
select*from service_transaction
select*from purchase
select* from customer
select*from Menu
select* from menu_services_transaction_detail
select* from ingredient
select* from ingredient_purchase_detail
select* from vendor

delete Menu
delete service_transaction
delete ingredient
delete purchase
delete ingredient_purchase_detail
delete position
delete Staff
delete vendor


--d
-- Simulate Services Transaction Process
-- pertama yang saya lakukan adalah membuat Stored Procedure degan nama SelectTransaction untuk menampilkan bukti Transaction dari salah satu ID yang berada pada tabel Customer. 
go
create procedure SelectTransaction @Customer_ID char(5)
AS
select st.transactionID as[Transaction ID], c.[Name] as [Customer Name], s.[Name] as [Staff Name], c.Email as [Customer Email], 
st.Transaction_date as [Transaction Date], st.Reservation_type as [Reservation Type], st.Pax_menu as [Pax Menu], m.[Name] as [Menu Name], m.[Description] as [Menu Description], 'Rp.' + cast(m.Price as varchar) as [Price]
from menu_services_transaction_detail mst join Menu m on mst.Menumenu_ID = m.Menu_ID join service_transaction st on mst.services_transactiontransactionID = st.transactionID join customer c on st.CustomerID = c.CustomerID join Staff s on st.StaffID = s.StaffID
where c.CustomerID = @Customer_ID

-- Simulasi Yaitu terdapat Seorang Customer baru yang bernama Hansen dengan Customer ID CU011 , No telepon 081293040345 , Alamat Rumah di Jl. Kimangun Sarkoro , gender Male dan memilik email yaitu Hansen123@gmail.com
select* from customer
begin tran
insert into customer values('CU011', 'Hansen', '081293040345', 'Jl. Kimangun Sarkoro', 'Male', 'Hansen123@gmail.com')
rollback

--lalu seorang Customer tersebut ingin melakukan sebuah transaksi dengan memesan sebuah Menu yang tertera pada tabel Menu tersebut.
--yang mana di table Services Transaction tersebut terdapat Customer ID yang didapat dari table Customer, Staff ID yang di dapet dari table Staff,
--tanggal dari transaksi tersebut, tipe reservasinya, alamatnya , dan berapa jumlah Pax menu yang ingin dipesan oleh Customer Tersebut. 
select* from service_transaction
begin tran
insert into service_transaction values('TR016', 'ST001', 'CU011', '2020-09-23', 'Catering', 'Jl. Malioboro', '120')
rollback

--Setelah itu, Customer tersebut memesan beberapa menu yaitu ME006 dan ME003 adalah Nasi Goreng Hongkong dan Kambing Gulai.dimana pada tahap ini sebuah transaction ID dihubungnkan berdasarkan Menu ID yang telah dipesan oleh Customer tersebut
--yang nantinya Menu ID tersebut akan melakukan References ke tabel Menu yang berisikan Menu ID, Nama menu berdasarkan Menu ID, Description dan Harga dari menu tersebut.
select* from menu_services_transaction_detail
begin tran 
insert into menu_services_transaction_detail values('ME006', 'TR016')
insert into menu_services_transaction_detail values('ME003', 'TR016')
rollback

select* from Menu
--terakhir EXEC. EXEC digunakan untuk mengexecute Procedure yang telah kita bentuk di atas untuk menamipilkan bukti Transaction berdasarkan Customer Baru yaitu CU011.
EXEC SelectTransaction 'CU011'

--Simulate Purchase Process
go
create procedure SelectPurchaseTransaction @Vendor_ID char(5)
AS
select p.purchase_ID as [Purchase ID], v.[Name] as [Vendor Name], p.Purchase_date as [Purchase Date], ipd.quantity_ingredient, i.[Name] as [Ingredient Name], 'Rp.' + cast(i.Price as varchar) as [Ingredient Price]
from ingredient_purchase_detail ipd join ingredient i on ipd.ingredient_ingredient_ID = i.ingredient_ID join purchase p on ipd.purchase_purchase_ID = p.purchase_ID join vendor v on p.VendorID = v.VendorID join Staff s on p.StaffID = s.StaffID
where v.VendorID = @Vendor_ID

-- Keesokan harinya terdapat sebuah vendor baru yaitu PT.Sukses Makmur dengan Vendor ID VE011 , No telepon 0812193245961 , Alamat Rumah di Jl.Senen Raya.
select* from vendor
begin tran
insert into vendor values('VE011', 'PT.Sukses Makmur', '0812193245961', 'Jl.Senen Raya')
rollback

--lalu Vendor tersebut ingin melakukan sebuah pembelian dengan memesan sebuah bahan-bahan yang tertera pada tabel ingredient tersebut.
--yang mana di table Purchase tersebut terdapat Vendor ID yang didapat dari table Vendor, Staff ID yang di dapet dari table Staff,
--serta tanggal dari transaksi tersebut.
select* from purchase
begin tran 
insert into purchase values('PU016', 'ST005','VE011', '2020-03-23')
rollback

--Setelah itu, Vendor tersebut memesan beberapa Ingredient yaitu ID004, ID006 dan ID010 adalah ikan Gurame, Ikan Kakap, dan Kambing Gulai.dimana pada tahap ini ingredient ID dihubungnkan berdasarkan Purchase ID yang telah dipesan oleh Vendor tersebut
--yang nantinya Vendor ID yang berada pada tabel ingredient purcahse detail tersebut akan melakukan References ke tabel Ingredient yang berisikan ingredient ID, Nama ingredient berdasarkan ingredient ID, Stock dan Harga dari ingredient tersebut.
select* from ingredient_purchase_detail
begin tran
insert into ingredient_purchase_detail values('ID004', 'PU016', 6)
insert into ingredient_purchase_detail values('ID006', 'PU016', 4)
insert into ingredient_purchase_detail values('ID010', 'PU016', 2)
rollback

select* from ingredient
--terakhir EXEC. EXEC digunakan untuk mengexecute Procedure yang telah kita bentuk di atas untuk menamipilkan bukti Purchase berdasarkan Vendor Baru yaitu VE011.
exec SelectPurchaseTransaction 'VE011'